def test():
	global a
	a=1

def test2():
	global a
	print(a)

test()
test2()